
package vista;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import adosa2Game.LogicGame;

/**
 *
 * @author 
 */
public class JuegoFinal extends JFrame {

    private String rutaAbsoluta;
    private int ancho;
    private int largo;
    private JButton btnJugar;
    private JLabel lblFondo;
    private JLabel lblPuntajeLogic;
    private JLabel lblAciertosLogic;
    private JLabel lblFallosLogic;
    private Container contPrincipal;
    private LogicGame logica;

    public JuegoFinal(LogicGame logica) throws IOException {
        ancho = 700;
        largo = 500;

        this.logica = logica;

        setSize(ancho, largo);
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Adosa2_Game");
        setResizable(false);

        inciarComponentes();
    }

    private void inciarComponentes() throws IOException {
        
        rutaAbsoluta = new File("").getAbsolutePath();
        lblFondo = new JLabel(establecerIcon("/src/imagenes/fondoFinal.png",ancho, largo));
        lblFondo.setBounds(0, 0, ancho, largo);
        
        //Llamamos los objects
        PuntajeLogic();
        AciertoLogic();
        FalloLogic();
        BtnJugar();
        ContePrincipal();

    }
    
    
    private void PuntajeLogic(){
        lblPuntajeLogic = new JLabel(logica.getPuntaje() + "");
        lblPuntajeLogic.setForeground(Color.yellow);
        lblPuntajeLogic.setFont(new Font("cooper black",1,45));
        lblPuntajeLogic.setBounds(420, 145, 220, 50); 
        lblFondo.add(lblPuntajeLogic);
    }
    
    
    private void AciertoLogic(){
        lblAciertosLogic = new JLabel(logica.getAciertos() + "");
        lblAciertosLogic.setForeground(Color.yellow);
        lblAciertosLogic.setFont(new Font("cooper black",1,45));
        lblAciertosLogic.setBounds(420, 230, 220, 50); 
        lblFondo.add(lblAciertosLogic);
    }

    
    private void FalloLogic(){
        lblFallosLogic = new JLabel(logica.getFallos() + "");
        lblFallosLogic.setForeground(Color.yellow);
        lblFallosLogic.setFont(new Font("cooper black",1,45));
        lblFallosLogic.setBounds(420, 310, 220, 50); 
        lblFondo.add(lblFallosLogic);
    }

    
    private void BtnJugar(){
        btnJugar = new JButton("");
        btnJugar.setBounds(200, 380, 300, 75);
        btnJugar.setRolloverEnabled(true);
        btnJugar.setFocusPainted(false);
        btnJugar.setBorderPainted(false);
        btnJugar.setContentAreaFilled(false);
        btnJugar.addActionListener(new ManejadorDeEventos());
        lblFondo.add(btnJugar);
    }

    
    private void ContePrincipal(){
        contPrincipal = getContentPane();
        contPrincipal.setLayout(null);
        contPrincipal.add(lblFondo);
    }


    private ImageIcon establecerIcon(String rutaArchivo, int ancho, int alto)
            throws IOException {
        BufferedImage bufferedImagen = ImageIO.read(new File(rutaAbsoluta.concat(rutaArchivo)));
        Image imagen = bufferedImagen.getScaledInstance(ancho, alto, Image.SCALE_DEFAULT);
        return new ImageIcon(imagen);
    }

    private class ManejadorDeEventos implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            dispose();
            try {
                Menu Inicio = new Menu(0);
            } catch (IOException ex) {
                Logger.getLogger(JuegoFinal.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }
}
