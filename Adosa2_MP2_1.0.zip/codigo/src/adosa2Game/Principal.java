
package adosa2Game;

import java.io.IOException;
import vista.Menu;
import vista.Jugar;

/**
 *
 * @author 
 */
public class Principal {

    public static void main(String[] args) throws IOException {
        Menu Iniciando = new Menu(0);
    }
    
}
