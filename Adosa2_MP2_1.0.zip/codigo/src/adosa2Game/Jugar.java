
package vista;


import adosa2Game.Baldosas;

import javax.swing.Timer;
import adosa2Game.LogicGame;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.logging.Level;
import javax.swing.BorderFactory;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.io.IOException;
import javax.swing.Icon;


/**
 *
 * @author 
 */
public class Jugar extends JFrame {
    
    
    //Ancho y alto de ventana
    private int anchoV = 700;
    private int largoV = 500;
    private Timer tiempo;
    private JLabel lblPuntaje;
    private JLabel lblFondo;
    private JLabel lblContador;
    private JButton btnBlanco;
    private ImageIcon imgFondo;
    private ImageIcon BtnClik;
    private Baldosas imgsBaldosas;
    private int baldosaCambiada = -1;
    private LogicGame logica;
    private Container contPrincipal;
    
    private boolean puedeJugar = false;
    private boolean puedeTirar = false;
    private double tAux = 0;
    private boolean inicioJuego = true;

    private String rutaAbsoluta;
    private ArrayList<JLabel> listaVidas;
    private ArrayList<JLabel> listaBaldosas;



    public Jugar() throws IOException {
        iniciarVentana();
        iniciarComponentes();
    }

    private void iniciarVentana() {
        setSize(anchoV, largoV);
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        setTitle("Adosa2_Game");

        setResizable(false);

    }

    private void iniciarComponentes() throws IOException {

        //Ruta absoluta//
        rutaAbsoluta = new File("").getAbsolutePath();

        //logica
        logica = new LogicGame();

        //baldosas (controlador)
        imgsBaldosas = new Baldosas();

        //timer//
        tiempo = new Timer(100, new ManejadorDeEventosTiempo());
        tiempo.start();

        //Fondo (provisonal)//
        imgFondo = establecerIcon("/src/imagenes/fondoJuego.png", anchoV - 10,largoV - 38);
        lblFondo = new JLabel(imgFondo);
        lblFondo.setLayout(null);
        BtnClik = establecerIcon("/src/imagenes/click.png", 100, 100);
        
        //Labels de vidas// (temporales)
        listaVidas = new ArrayList<>();
        inicializarVidas();

        //Baldosas//
        listaBaldosas = new ArrayList<>();
        inicializarBaldosas();

        //se añaden las baldosas
        for (int i = 0; i < 8; i++) {
            lblFondo.add(listaBaldosas.get(i));
        }
        for (int i = 0; i < 3; i++) {
            lblFondo.add(listaVidas.get(i));
        }
        
        //Lamamos los objetos
        lblpuntaje();
        btnBlanco();
        lblcontador();
        contPrinci();


    }
    
    
    private void lblpuntaje(){
        lblPuntaje = new JLabel("Puntaje: 0000");
        lblPuntaje.setForeground(Color.MAGENTA);
        lblPuntaje.setBounds(5, 0, 220, 50);
        lblPuntaje.setFont(new Font("cooper black",3, 25));
        lblFondo.add(lblPuntaje);
    }
    
    private void btnBlanco(){
        btnBlanco = new BotonSinFondo();
        btnBlanco.setBounds(520, 320, 100, 100);
        btnBlanco.setIcon(BtnClik);
        lblFondo.add(btnBlanco);
        btnBlanco.addMouseListener(new ManejadorDeEventosMouse());
        btnBlanco.addKeyListener(new ManejadorDeEventosTeclado());

    }
    
    private void lblcontador(){
        lblContador = new JLabel();
        lblContador.setBounds(300, 100, 300, 250);
        lblContador.setBorder(null);
        lblFondo.add(lblContador);
    
    }
    
    private void contPrinci(){
        contPrincipal = getContentPane();
        contPrincipal.setLayout(new GridLayout(1, 1));
        contPrincipal.add(lblFondo);
    
    }

    //Metodo que retorna una imagen con el ancho y alto recibido
    private ImageIcon establecerIcon(String rutaArchivo, int ancho, int alto)
            throws IOException {
        BufferedImage bufferedImagen = ImageIO.read(new File(rutaAbsoluta.concat(rutaArchivo)));
        Image imagen = bufferedImagen.getScaledInstance(ancho, alto, Image.SCALE_DEFAULT);
        return new ImageIcon(imagen);
    }

    //clasee manejadora de eventos del mouse
    private class ManejadorDeEventosMouse extends MouseAdapter {

        @Override
        public void mousePressed(MouseEvent e) {
            //si se da click en el boton balnco
            if (e.getSource() == btnBlanco) {
                if (puedeJugar && puedeTirar) {
                    if (baldosasIguales(baldosaCambiada)) {
                        tAux = 0;
                        acierto();

                    } else {
                        try {
                            tAux = 0;
                            falloCometido();
                        } catch (IOException ex) {
                            Logger.getLogger(Jugar.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            }
        }
    }


    private class ManejadorDeEventosTeclado extends KeyAdapter {

        @Override
        public void keyPressed(KeyEvent e) {

            if (e.getKeyCode() == 32) {
                if (puedeJugar && puedeTirar) {
                    if (baldosasIguales(baldosaCambiada)) {
                        tAux = 0;
                        acierto();
                    } else {
                        try {
                            tAux = 0;
                            falloCometido();
                        } catch (IOException ex) {
                            Logger.getLogger(Jugar.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
            }
        }
    }


    private class ManejadorDeEventosTiempo implements ActionListener {


        private double t = 0;

        private boolean cuentaRegresiva = true;

        @Override
        public void actionPerformed(ActionEvent e) {
            //se aumenta el tiempo 1 decimo de segundo
            tAux += 0.1;
            t += 0.1;

            if (tAux > 0.5) {
                puedeTirar = true;
            } else {
                if (!inicioJuego) {
                    puedeTirar = false;
                }
            }

            if (t >= 4) {
         //       inicializarVolumen();
                puedeJugar = true;
                puedeTirar = true;
                inicioJuego = false;
            }

            if (cuentaRegresiva) {
                if (t < 4) {
                    if (0 <= t && t < 1) {
                        try {
                            lblContador.setIcon(establecerIcon("/src/imagenes/imgnum1.png", 100, 250));
                        } catch (IOException ex) {
                            Logger.getLogger(Jugar.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else if (1 <= t && t < 2) {
                        try {
                            lblContador.setIcon(establecerIcon("/src/imagenes/imgnum2.png", 100, 250));
                        } catch (IOException ex) {
                            Logger.getLogger(Jugar.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else if (2 <= t && t < 3) {
                        try {
                            lblContador.setIcon(establecerIcon("/src/imagenes/imgnum3.png", 100, 250));
                        } catch (IOException ex) {
                            Logger.getLogger(Jugar.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else {
                        lblContador.setBounds(200, 100, 300, 250);
                        try {
                            lblContador.setIcon(establecerIcon("/src/imagenes/go.png", 300, 250));
                        } catch (IOException ex) {
                            Logger.getLogger(Jugar.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                } else {

                    lblContador.setVisible(false);
                    modificarBaldosas();
                    cuentaRegresiva = false;
                    t = 0;
                }
            } else {
                if (t > logica.getTiempoDeCambio()) {
                    t = 0;

                    if (baldosasIguales(baldosaCambiada)) {
                        try {
                            falloCometido();
                        } catch (IOException ex) {
                            Logger.getLogger(Jugar.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } else {

                        if (baldosaCambiada != -1) {
                            listaBaldosas.get(baldosaCambiada).setBorder(null);
                        }

                        int baldosaACambiar = logica.CambiaBaldosas();
                        listaBaldosas.get(baldosaACambiar).setIcon(imgsBaldosas.getImgBaldosaAleatoria());
                        listaBaldosas.get(baldosaACambiar).setBorder(BorderFactory.createLineBorder(Color.GREEN, 3));
                        baldosaCambiada = baldosaACambiar;
                    }
                }
            }
        }
    }


    private void inicializarBaldosas() {

        int coordenadas[][] = {{30, 172}, {140, 172}, {440, 180}, {550, 180},
        {292, 7}, {292, 108}, {292, 353}, {292, 252}};

        for (int i = 0; i < 8; i++) {
            JLabel baldosa = new JLabel(imgsBaldosas.getImgBaldosa(i));
            baldosa.setBounds(coordenadas[i][0], coordenadas[i][1],100, 100);
            baldosa.setVisible(false);
            this.listaBaldosas.add(baldosa);
        }
    }

    private void inicializarVidas() {
        int coordenadas[][] = {{480, 10}, {550, 10}, {620, 10}};
        for (int i = 0; i < 3; i++) {
            LblVida lblVida = new LblVida();
            lblVida.setBounds(coordenadas[i][0], coordenadas[i][1], 50, 50);
            listaVidas.add(lblVida);
        }
    }

    private class LblVida extends JLabel {

        public LblVida() {
            setOpaque(true);
            setBackground(Color.MAGENTA);
        }

    }

    private boolean baldosasIguales(int baldosaCambiada) {


        boolean hayBaldosasIguales = false;
        if (baldosaCambiada != -1) {
            ArrayList<Integer> baldosasEnPantalla = logica.getSaleBaldosa();
            Icon imgBaldosaCambiada = listaBaldosas.get(baldosaCambiada).getIcon();
            for (int i = 0; i < baldosasEnPantalla.size(); i++) {
                if (baldosaCambiada != baldosasEnPantalla.get(i)) {
                    Icon imgBaldosa = listaBaldosas.get(baldosasEnPantalla.get(i)).getIcon();
                    if (imgBaldosaCambiada == imgBaldosa) {
                        hayBaldosasIguales = true;
                    }
                }
            }
        }

        return hayBaldosasIguales;
    }


    private void quitarUnaVida() {
        if (logica.getVidas() > 0) {
            listaVidas.get(logica.getVidas()).setBackground(Color.red);
        }

    }


    private void modificarBaldosas() {

        for (int i = 0; i < 8; i++) {
            if (logica.SaleBaldosa(i)) {
                listaBaldosas.get(i).setVisible(true);
            } else {
                listaBaldosas.get(i).setVisible(false);
            }
            listaBaldosas.get(i).setIcon(imgsBaldosas.getImgBaldosa(i));
        }
    }


    private void falloCometido() throws IOException {
        if (logica.getVidas() != 1) {

        } 

        if (baldosaCambiada != -1) {
            listaBaldosas.get(baldosaCambiada).setBorder(null);
        }
        baldosaCambiada = -1;
        logica.BaldosasIguales();
        quitarUnaVida();
        logica.FallosMas();
        logica.aumCambio();
        if (logica.getVidas() > 0) {
            logica.SaleBaldosaNueva();
            modificarBaldosas();
        } else {
            tiempo.stop();
            dispose();
            JuegoFinal Final = new JuegoFinal(this.logica);


        }

    }

    private void acierto() {
        listaBaldosas.get(baldosaCambiada).setBorder(null);

        logica.PuntosMas();
        logica.PtsMas();
        lblPuntaje.setText("Puntaje: " + logica.getPuntaje());

        logica.AciertosMas();

        logica.rduCambio();

        logica.BaldosaMas();
        logica.SaleBaldosaNueva();
        modificarBaldosas();

        baldosaCambiada = -1;
    }

    //Clase de boton sin fondo ni bordes
    private class BotonSinFondo extends JButton {

        public BotonSinFondo() {
            inicializar();
        }

        private void inicializar() {
            setRolloverEnabled(true);
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
        }
    }

}
