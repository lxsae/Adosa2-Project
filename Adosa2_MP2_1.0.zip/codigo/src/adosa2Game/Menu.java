
package vista;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.Timer;
import java.awt.Container;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import javax.imageio.ImageIO;
import javax.sound.sampled.Clip;


/**
 *
 * @author 
 */
public class Menu extends JFrame {
    
    //Ancho y alto de ventana
    private int anchoV = 700;
    private int largoV = 500;
    private ImageIcon imgFondo;
    private JLabel lblFondo;
    private JButton btnJugar;
    private JButton btnParaQueSirve;
    private JButton btnComoJugar;
    private Container contPrincipal;
    private Clip clip;
    private boolean pasoVentana;
    private int opcion;
    private Timer tiempo;

    //Ruta absoluta
    private String rutaAbsoluta;

    public Menu(int opcion) throws IOException {
        iniciarComponentes();
        iniciarVentana();
        this.opcion = opcion;
        this.pasoVentana = false;
    }

    private void iniciarVentana() throws IOException {
        setSize(anchoV, largoV);
        setVisible(true);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Adosa2_Game");
        setResizable(false);
    }

    private void iniciarComponentes() throws IOException {
        //Ruta absoluta
        rutaAbsoluta = new File("").getAbsolutePath();
        //Fondo
        imgFondo = establecerIcon("/src/imagenes/fondoMenu.png",anchoV, largoV);
        
        //Llamamos de Objetos
        CrearLbls();
        CrearTiempo();
        BotonJuega();
        BotonComoJuega();
        BotonParaQSirve();
        ContenPrincipal();
    }

    public void CrearLbls(){
        lblFondo = new JLabel(imgFondo);
        lblFondo.setBounds(0, 0, anchoV, largoV);
                
    }
    
    public void CrearTiempo(){
        tiempo = new Timer(100, new ManejadorDeEventosTiempo());
        tiempo.start();}
    
    public void BotonJuega(){
        btnJugar = new BotonSinFondo();
        btnJugar.setBounds(220, 280, 250, 150);
        lblFondo.add(btnJugar);
        btnJugar.addMouseListener(new ManejadorDeEventos());
    }
    
    public void BotonComoJuega(){
        btnComoJugar = new BotonSinFondo();
        btnComoJugar.setBounds(10, 280, 200, 130);
        lblFondo.add(btnComoJugar);
        btnComoJugar.addMouseListener(new ManejadorDeEventos());
    
    }
    
    public void BotonParaQSirve(){
        btnParaQueSirve = new BotonSinFondo();
        btnParaQueSirve.setBounds(470, 280, 200, 130);
        lblFondo.add(btnParaQueSirve);
        btnParaQueSirve.addMouseListener(new ManejadorDeEventos());
    }
    
    public void ContenPrincipal(){
        contPrincipal = getContentPane();
        contPrincipal.setLayout(null);
        contPrincipal.add(lblFondo);
    }
    
    //Metodo que retorna una imagen con el ancho y alto recibido
    private ImageIcon establecerIcon(String rutaArchivo, int ancho, int alto)
            throws IOException {
        BufferedImage bufferedImagen = ImageIO.read(new File(rutaAbsoluta.concat(rutaArchivo)));
        Image imagen = bufferedImagen.
                getScaledInstance(ancho, alto, Image.SCALE_DEFAULT);
        return new ImageIcon(imagen);
    }

    private class ManejadorDeEventos extends MouseAdapter {

        @Override
        public void mousePressed(MouseEvent e) {
            if (e.getSource() == btnJugar) {
                dispose();
                try {
                    pasoVentana = true;
                    if (clip != null) {
                        clip.stop();
                    }
                    Jugar EmpiezaJuego = new Jugar();
                } catch (IOException ex) {
                    Logger.getLogger(Menu.class.getName()).
                            log(Level.SEVERE, null, ex);
                }
            } else if (e.getSource() == btnComoJugar) {
                dispose();

                try {
                    if (clip != null) {
                        clip.stop();
                    }
                    pasoVentana = true;
                    ComoJugar ComoSeJuega = new ComoJugar();

                } catch (IOException ex) {
                    Logger.getLogger(Menu.class.getName()).
                            log(Level.SEVERE, null, ex);
                }
            } else if (e.getSource() == btnParaQueSirve) {
                dispose();
                try {
                    if (clip != null) {
                        clip.stop();
                    }
                    pasoVentana = true;
                    ParaQueSirve Leer = new ParaQueSirve();
                } catch (IOException ex) {
                    Logger.getLogger(Menu.class.
                            getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }

    private class ManejadorDeEventosTiempo implements ActionListener {

        private double t = 0;


        @Override
        public void actionPerformed(ActionEvent e) {

            t += 0.1;

        }
    }

    //Clase de boton sin fondo ni bordes
    private class BotonSinFondo extends JButton {

        public BotonSinFondo() {
            inicializar();
        }

        private void inicializar() {
            setRolloverEnabled(true);
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
        }
    }
    


}
